########################################
#                                      #
#        Smirnoff Kids Homepage        #
#                                      #
########################################

Gruppe:
* 10

Matrikelnummern:
* 6160077
* 7306389
* 1032801
* 5563375

Kontaktaddresse bei Problemen(z.B. Ausführung):
* Mircosoft_heck@web.de

Getestet über:
* http://smirnoff-kids.de/we/

XAMPP-Version:
* XAMPP for Windows 8.1.2

Hinweise:
* Online Validator bemängelt Präsenz des "active" Attributs im Menü, dies ist allerdings gewollt, um CSS mit Attributselektor zu vereinfachen.